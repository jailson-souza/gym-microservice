-- AlterTable
ALTER TABLE "Exercise" ADD COLUMN "isActive" BOOLEAN DEFAULT true;

-- AlterTable
ALTER TABLE "Muscle" ADD COLUMN "isActive" BOOLEAN DEFAULT true;

-- AlterTable
ALTER TABLE "Student" ADD COLUMN "isActive" BOOLEAN DEFAULT true;

-- AlterTable
ALTER TABLE "Workout" ADD COLUMN "isActive" BOOLEAN DEFAULT true;
