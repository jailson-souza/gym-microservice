-- AlterTable
ALTER TABLE "User" ADD COLUMN "studentId" TEXT;
