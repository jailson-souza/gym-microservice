export class CredentialDto {
  expiresIn: number;
  token: string;
}
