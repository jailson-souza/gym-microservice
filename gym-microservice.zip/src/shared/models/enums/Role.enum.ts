export enum RoleEnum {
  Admin = 'admin',
  Teacher = 'teacher',
  Student = 'student',
}
