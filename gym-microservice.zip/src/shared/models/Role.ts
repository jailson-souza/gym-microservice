export type Role = {
  id?: string;
  key: string;
  name: string;
  isActive: boolean;
};
