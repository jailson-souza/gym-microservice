export type Muscle = {
  id?: string;
  name: string;
  isActive?: boolean;
};
